Erssical
========

Fetching, merging and filtering Event RSS feeds and converting to ical.

More information on Erssical's website: http://zoggy.github.io/erssical/ .